import random  # чтобы пауза была случайной в диапазоне
import time  # для пауз между запросами (time.sleep)

import httpx
from bs4 import BeautifulSoup

# --- наши собственные модули ---
from database import SessionLocal  # фабрика сессий к БД (объявили в database.py)
from fetch_retry import fetch_chapter_with_retry
from models import Chapter  # ORM-модель таблицы chapters (из models.py)

# Переиспользуем уже проверенные функции из тестового скрипта.
# ВАЖНО: импорт test_parse НЕ запустит его тест — тот код спрятан под
# `if __name__ == "__main__"`, который срабатывает только при ПРЯМОМ запуске файла.
from scraper import (
    CHAPTER_URL,
    HEADERS,
    fetch_chapter_list,
    normalize_ws,
    parse_article,
)

MIN_DELAY = 1.0   # минимальная пауза между запросами (секунды)
MAX_DELAY = 2.5   # максимальная пауза


def container_text_len(html):
    """Длина чистого текста тела статьи (без сносок) — эталон для проверки полноты."""
    soup = BeautifulSoup(html, "lxml")
    node = soup.find(id="roodNodeOfShareText")
    if not node:
        return 0
    fnsec = node.find("section", class_="footnotes")
    if fnsec:
        fnsec.decompose()                 # убрать сноски, чтобы мерить только тело
    normalize_ws(node)
    return len(node.get_text(" ", strip=True))


def body_text_len(content_html):
    """Длина чистого текста из нашего content_html (снимаем HTML-теги)."""
    return len(BeautifulSoup(content_html, "lxml").get_text(" ", strip=True))


def run():
    chapters = fetch_chapter_list()
    total = len(chapters)
    print(f"Глав в оглавлении: {total}\n")   # f"..." — f-строка: {total} подставит значение

    session = SessionLocal()                 # открываем «разговор» с базой (сессию)
    added = skipped = failed = 0             # счётчики (все три = 0)
    warnings = []                            # сюда соберём подозрительно короткие главы

    try:
        # enumerate даёт пары (номер_итерации, элемент); start=1 — нумеровать с 1
        for i, ch in enumerate(chapters, start=1):
            prefix = f"[{i}/{total}] №{ch['number']}"

            # 1) уже в базе? пропускаем — скрипт можно безопасно перезапускать
            if session.query(Chapter).filter_by(number=ch["number"]).first():
                skipped += 1
                print(f"{prefix} уже есть — пропуск")
                continue                     # перейти к следующей главе

            try:
                # 2) качаем с повторами (сервер иногда отдаёт каркас без текста)
                data, info = fetch_chapter_with_retry(ch)
                if not data:
                    failed += 1
                    print(f"{prefix} — {info}")
                    continue

                # 3) создаём строку-объект и пишем в базу
                chapter = Chapter(
                    number=data["number"],
                    title=data["title"],
                    heard=data["heard"],
                    content_html=data["content_html"],
                    footnotes=data["footnotes"],   # список -> SQLAlchemy сам сложит в JSON
                    source_url=data["source_url"],
                )
                session.add(chapter)         # поставить в очередь на запись
                session.commit()             # зафиксировать (по одной главе: при сбое уже сохранённое не потеряется)
                added += 1
                # :.0% — формат: показать долю как проценты без дробной части
                print(f"{prefix} '{data['title'][:45]}' — {info}")

            except Exception as e:           # ошибка на одной главе не должна ронять весь проход
                session.rollback()           # откатить незавершённую запись
                failed += 1
                print(f"{prefix} — ОШИБКА: {e}")

            # 4) пауза перед следующим запросом — вежливость к серверу и защита от бана
            time.sleep(random.uniform(MIN_DELAY, MAX_DELAY))

    finally:
        session.close()                      # закрыть сессию в любом случае (даже при ошибке)

    print(f"\nГотово. Добавлено: {added}, пропущено: {skipped}, ошибок: {failed}")
    if warnings:
        print("Возможно неполные — проверь вручную (глава: покрытие):")
        for num, cov in warnings:
            print(f"   №{num}: {cov}")


if __name__ == "__main__":
    run()