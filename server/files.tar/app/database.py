import os
from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase

load_dotenv()  # читает .env

DATABASE_URL = os.getenv("DATABASE_URL")

# engine — «мотор», управляет подключениями к базе
engine = create_engine(DATABASE_URL)

# фабрика сессий — через них делаем запросы
SessionLocal = sessionmaker(bind=engine)

# базовый класс для будущих моделей-таблиц
class Base(DeclarativeBase):
    pass
